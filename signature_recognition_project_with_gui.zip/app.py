
# Signature Recognition Streamlit App

import streamlit as st
from keras.preprocessing import image
import numpy as np
from keras.models import load_model
import cv2
import tensorflow as tf
from keras import backend as K
import matplotlib.pyplot as plt

# Load the trained model (replace with your model file path)
MODEL_PATH = "siamese_network.h5"  # Example model path
model = load_model(MODEL_PATH)

# Image dimensions
IMG_WIDTH, IMG_HEIGHT = 128, 128

def preprocess_image(img):
    img = cv2.resize(img, (IMG_WIDTH, IMG_HEIGHT))
    img = img.astype("float32") / 255.0
    img = np.expand_dims(img, axis=0)  # Expand dimensions for batch input
    return img

def predict_signature(img1, img2, model):
    # Preprocess both images
    img1_processed = preprocess_image(img1)
    img2_processed = preprocess_image(img2)
    
    # Make prediction using the model
    prediction = model.predict([img1_processed, img2_processed])
    
    if prediction[0][0] > 0.5:
        return "Predicted: Genuine Signature", prediction[0][0]
    else:
        return "Predicted: Forged Signature", prediction[0][0]

# GUI with Streamlit
st.title("Signature Recognition and Verification")

st.write("Upload two signature images to verify if they are genuine or forged.")

# File uploader for the first signature image
uploaded_file1 = st.file_uploader("Choose the first signature image", type=["jpg", "png", "jpeg"])

# File uploader for the second signature image
uploaded_file2 = st.file_uploader("Choose the second signature image (for comparison)", type=["jpg", "png", "jpeg"])

if uploaded_file1 is not None and uploaded_file2 is not None:
    # Load the uploaded images
    img1 = image.load_img(uploaded_file1, target_size=(IMG_WIDTH, IMG_HEIGHT), color_mode='grayscale')
    img1 = image.img_to_array(img1)
    img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    
    img2 = image.load_img(uploaded_file2, target_size=(IMG_WIDTH, IMG_HEIGHT), color_mode='grayscale')
    img2 = image.img_to_array(img2)
    img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    
    # Display the uploaded images
    st.image([uploaded_file1, uploaded_file2], caption=['First Signature', 'Second Signature'], width=200)
    
    # Predict if the signatures are genuine or forged
    result, confidence = predict_signature(img1, img2, model)
    
    st.write(f"Result: {result}")
    st.write(f"Confidence: {confidence:.2f}")
